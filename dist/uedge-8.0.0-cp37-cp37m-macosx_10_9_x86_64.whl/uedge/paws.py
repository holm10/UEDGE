def paws():
    programPause = raw_input("Press the <ENTER> key to continue...")
