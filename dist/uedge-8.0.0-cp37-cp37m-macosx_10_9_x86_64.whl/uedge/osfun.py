def date():
    os.system("date")

def ls(opts=""):
    os.system("ls " + opts)

def more(fname):
    os.system("more " + fname)

def pwd():
    os.system("pwd")

def cp(opts=""):
    os.system("cp " + opts)

def mv(opts=""):
    os.system("mv " + opts)
